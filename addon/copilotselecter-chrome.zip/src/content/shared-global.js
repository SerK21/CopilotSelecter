(function initCopilotDefaultModelShared(global) {
  const MODEL_PRESETS = [
    {
      id: "smart",
      name: "自動",
      description: "考える時間の長さを自動で決める標準モード",
      modeKey: "smart",
      matchLabels: ["自動", "Auto", "Smart", "スマート"],
    },
    {
      id: "quick",
      name: "クイック応答",
      description: "すぐに回答するモード",
      modeKey: null,
      matchLabels: ["クイック応答"],
    },
    {
      id: "reasoning",
      name: "Think Deeper",
      description: "より良い回答のために長く考える（トップレベル）",
      modeKey: "reasoning",
      matchLabels: ["Think Deeper", "Think deeper", "より深く考える"],
      excludeLabels: ["GPT"],
    },
    {
      id: "study",
      name: "Study and learn",
      description: "学習・クイズ向けモード（個人 Copilot）",
      modeKey: "study",
      matchLabels: ["Study and learn", "Study", "学習と学ぶ"],
    },
    {
      id: "search",
      name: "Search",
      description: "Web 検索重視モード（個人 Copilot）",
      modeKey: "search",
      matchLabels: ["Search"],
    },
    {
      id: "gpt-sol",
      name: "GPT 5.6 Sol",
      description: "GPT サブメニューの 5.6 Sol",
      modeKey: null,
      parentLabels: ["GPT", "OpenAI"],
      matchLabels: ["GPT 5.6 Sol", "GPT-5.6 Sol", "5.6 Sol", "GPT 5.6 ソル", "5.6 ソル"],
    },
    {
      id: "gpt-thinking",
      name: "GPT 5.6 Think Deeper",
      description: "GPT サブメニューの Think Deeper",
      modeKey: null,
      parentLabels: ["GPT", "OpenAI"],
      matchLabels: ["GPT 5.6 Think Deeper", "GPT-5.6 Think Deeper", "GPT 5.6 Think"],
    },
    {
      id: "gpt-quick",
      name: "GPT 5.6 Quick response",
      description: "GPT サブメニューの Quick response",
      modeKey: null,
      parentLabels: ["GPT", "OpenAI"],
      matchLabels: ["GPT 5.6 Quick response", "GPT-5.6 Quick response", "GPT 5.6 Quick"],
    },
    {
      id: "gpt-55-quick",
      name: "GPT 5.5 Quick Response",
      description: "GPT サブメニューの 5.5 Quick Response",
      modeKey: null,
      parentLabels: ["GPT", "OpenAI"],
      matchLabels: ["GPT 5.5 Quick Response", "GPT-5.5 Quick Response", "GPT 5.5 Quick"],
    },
    {
      id: "sonnet",
      name: "Claude Sonnet",
      description: "Claude サブメニューの Sonnet",
      modeKey: null,
      parentLabels: ["Claude", "Anthropic"],
      matchLabels: ["Sonnet"],
    },
    {
      id: "opus",
      name: "Claude Opus",
      description: "Claude サブメニューの Opus",
      modeKey: null,
      parentLabels: ["Claude", "Anthropic"],
      matchLabels: ["Opus"],
    },
  ];

  const SESSION_MODE_KEY = "sticky-conversation-mode";
  const STORAGE_KEY = "copilotDefaultModelSettings";

  const DEFAULT_SETTINGS = {
    enabled: true,
    modelId: "gpt-sol",
    applyOnLoad: true,
    applyOnNewChat: true,
    respectManualChangeMs: 15000,
  };

  function getPresetById(modelId) {
    return MODEL_PRESETS.find((preset) => preset.id === modelId) ?? MODEL_PRESETS[0];
  }

  function normalizeLabel(text) {
    return (text ?? "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function scoreLabelMatch(label, patterns, excludeLabels = []) {
    const normalized = normalizeLabel(label);
    if (!normalized) {
      return 0;
    }

    if (excludeLabels.some((item) => normalized.includes(normalizeLabel(item)))) {
      return 0;
    }

    let best = 0;
    for (const pattern of patterns) {
      const needle = normalizeLabel(pattern);
      if (!needle) {
        continue;
      }
      if (normalized === needle) {
        best = Math.max(best, 100 + needle.length);
      } else if (normalized.startsWith(needle)) {
        best = Math.max(best, 80 + needle.length);
      } else if (normalized.includes(needle)) {
        best = Math.max(best, 50 + needle.length);
      }
    }
    return best;
  }

  function labelMatches(label, patterns, excludeLabels = []) {
    return scoreLabelMatch(label, patterns, excludeLabels) > 0;
  }

  const GENERIC_SELECTOR_LABEL = /^(モデル\s*セレクター|model selector|select (a )?model|choose model)$/i;
  const LOADING_LABEL = /読み込|loading|spinner|please wait|^\s*[.…・…]+\s*$/i;
  const MODEL_READY_HINT =
    /自動|auto|smart|スマート|クイック応答|think deeper|より深く|gpt\s*5|claude|sonnet|opus|quick response/i;
  const MENU_READY_HINT =
    /自動|auto|smart|gpt|claude|think deeper|クイック応答|sonnet|opus|openai|anthropic/i;

  function isGenericSelectorLabel(label) {
    const raw = (label ?? "").replace(/\s+/g, " ").trim();
    return !raw || GENERIC_SELECTOR_LABEL.test(raw);
  }

  function isLoadingLabel(label) {
    return LOADING_LABEL.test((label ?? "").replace(/\s+/g, " ").trim());
  }

  function triggerLooksLoaded(label) {
    const raw = (label ?? "").replace(/\s+/g, " ").trim();
    if (!raw || isLoadingLabel(raw) || isGenericSelectorLabel(raw)) {
      return false;
    }
    return MODEL_READY_HINT.test(raw);
  }

  function menuLooksPopulated(labels) {
    const texts = (labels ?? []).map((item) => String(item ?? "").trim()).filter(Boolean);
    if (texts.length < 3) {
      return false;
    }
    return MENU_READY_HINT.test(texts.join(" "));
  }

  async function loadSettings() {
    const stored = await chrome.storage.sync.get(STORAGE_KEY);
    const current = { ...DEFAULT_SETTINGS, ...(stored[STORAGE_KEY] ?? {}) };
    const revision = current.settingsRevision ?? 0;
    if (revision < 3 && (current.modelId === "gpt-thinking" || !stored[STORAGE_KEY]?.modelId)) {
      current.modelId = "gpt-sol";
      current.settingsRevision = 3;
      try {
        await chrome.storage.sync.set({ [STORAGE_KEY]: current });
      } catch {
        // Restricted frames may not persist; the in-memory value is still Sol.
      }
    }
    return current;
  }

  global.CopilotDefaultModel = {
    MODEL_PRESETS,
    SESSION_MODE_KEY,
    STORAGE_KEY,
    DEFAULT_SETTINGS,
    getPresetById,
    labelMatches,
    scoreLabelMatch,
    normalizeLabel,
    loadSettings,
    isGenericSelectorLabel,
    isLoadingLabel,
    triggerLooksLoaded,
    menuLooksPopulated,
  };
})(globalThis);
